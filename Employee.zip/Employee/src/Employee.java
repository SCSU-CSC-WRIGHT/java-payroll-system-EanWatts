public class Employee {
    // Private fields
    private String name;
    private int employeeId;
    private String department;
    private double hourlyWage;
    private double hoursWorked;

    // Constructor
    public Employee(String name, int employeeId, String department, double hourlyWage, double hoursWorked) {
        this.name = name;
        this.employeeId = employeeId;
        this.department = department;
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    // Getter and setter methods for each field
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    // Calculating weekly salary
    public double calculateWeeklySalary() {
        double regularHours = 40;
        double overtimeRate = 1.5;
        double weeklySalary;

        if (hoursWorked > regularHours) {
            double overtimeHours = hoursWorked - regularHours;
            weeklySalary = (regularHours * hourlyWage) + (overtimeHours * hourlyWage * overtimeRate);
        } else {
            weeklySalary = hoursWorked * hourlyWage;
        }

        return weeklySalary;
    }

    // Override the toString() method
    @Override
    public String toString() {
        return String.format("Employee{name='%s', employeeId=%d, department='%s', hourlyWage=%.1f, hoursWorked=%.1f, weeklySalary=%.1f}",
                name, employeeId, department, hourlyWage, hoursWorked, calculateWeeklySalary());
    }
}



