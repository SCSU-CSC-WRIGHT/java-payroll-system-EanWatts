public class PayrollSystem {
    public static void main(String[] args) {
        // Making the employee objects
        Employee emp1 = new Employee("John Doe", 101, "Engineering", 25.0, 45.0);
        Employee emp2 = new Employee("Jane Smith", 102, "Marketing", 30.0, 40.0);
        Employee emp3 = new Employee("Bob Johnson", 103, "HR", 20.0, 50.0);

        // Showing information about the employees
        System.out.println(emp1);
        System.out.println(emp2);
        System.out.println(emp3);
    }
}

